class ScreenArguments {
  final bool enableAR;

  ScreenArguments({this.enableAR});
}
