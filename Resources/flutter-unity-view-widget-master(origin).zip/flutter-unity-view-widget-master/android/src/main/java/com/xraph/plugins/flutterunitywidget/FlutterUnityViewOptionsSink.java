package com.xraph.plugins.flutterunitywidget;

public interface FlutterUnityViewOptionsSink {
    void setAREnabled(boolean arEnabled);

    void setFullscreenEnabled(boolean fullscreenEnabled);

    void setSafeModeEnabled(boolean safeModeEnabled);
}
