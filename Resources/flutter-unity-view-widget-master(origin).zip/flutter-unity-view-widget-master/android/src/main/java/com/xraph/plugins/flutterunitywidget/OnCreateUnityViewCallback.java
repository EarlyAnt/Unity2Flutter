package com.xraph.plugins.flutterunitywidget;

public interface OnCreateUnityViewCallback {
  void onReady();
}
